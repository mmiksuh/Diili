import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import './style.css';

const products={
  sony:[
    ['Sony WH-1000XM5','Tori','159 €','Erinomainen','Espoo','0 €',94,'Hinta alle markkinan'],
    ['Sony WH-1000XM5','Tori','149 €','Hyvä','Helsinki','8 €',92,'Edullinen, hieman käytetty'],
    ['Sony WH-1000XM5','Huuto.net','169 €','Uudenveroinen','Tampere','7 €',91,'Uudenveroinen'],
    ['Sony WH-1000XM5','Tori','129 €','Tyydyttävä','Vantaa','8 €',78,'Halvin, mutta kulumaa'],
  ],
  iphone:[
    ['Apple iPhone 15 Pro 256GB','Tori','519 €','Erinomainen','Espoo','0 €',96,'Paras kokonaisuus'],
    ['Apple iPhone 15 Pro 256GB','Tori','499 €','Hyvä','Helsinki','8 €',95,'Hyvä hinta'],
    ['Apple iPhone 15 Pro 256GB','Huuto.net','479 €','Tyydyttävä','Tampere','8 €',82,'Halvin, mutta heikompi kunto'],
  ],
  ps5:[
    ['PlayStation 5 Slim','Tori','389 €','Erinomainen','Helsinki','0 €',96,'Paras kokonaisuus'],
    ['PlayStation 5 Slim','Tori','379 €','Hyvä','Vantaa','8 €',94,'Edullinen'],
    ['PlayStation 5 Slim','Huuto.net','359 €','Tyydyttävä','Turku','9 €',84,'Halvin, mutta heikompi kunto'],
  ],
  macbook:[
    ['MacBook Air M2 13”','Tori','729 €','Erinomainen','Espoo','0 €',97,'Paras kokonaisuus'],
    ['MacBook Air M2 13”','Tori','699 €','Hyvä','Helsinki','8 €',94,'Hyvä hinta'],
    ['MacBook Air M2 13”','Huuto.net','649 €','Tyydyttävä','Tampere','9 €',84,'Halvin, mutta heikompi kunto'],
  ]
};

function getKey(q){const s=q.toLowerCase(); if(s.includes('iphone'))return 'iphone'; if(s.includes('ps5'))return 'ps5'; if(s.includes('macbook'))return 'macbook'; return 'sony';}

function App(){
 const [q,setQ]=useState('Sony WH-1000XM5');
 const [items,setItems]=useState(products.sony);
 const [selected,setSelected]=useState(0);
 const [target,setTarget]=useState('140');
 const [watching,setWatching]=useState(false);
 const search=()=>{const k=getKey(q);setItems(products[k]);setSelected(0)};
 const x=items[selected]||items[0];
 return <><header><b>diili.</b><span>V2 · prototyyppi</span></header>
 <section className="hero"><h1>Älä osta vain halvinta.<br/>Osta paras diili.</h1><p>Vertaile käytettyjä tuotteita ja arvioi, onko hinta oikeasti hyvä.</p>
 <div className="search"><input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==='Enter'&&search()}/><button onClick={search}>Etsi diilit</button></div>
 <div className="chips">{['iPhone 15 Pro 256GB','PS5 Slim','MacBook Air M2','Sony WH-1000XM5'].map(v=><button key={v} onClick={()=>{setQ(v);setItems(products[getKey(v)]);setSelected(0)}}>{v}</button>)}</div></section>
 <main><div className="filters"><span>📍 Suomi</span><span>Kunto: hyvä+</span><span>Järjestys: paras diili</span></div>
 <div className="layout"><section className="panel"><div className="top"><div><h2>{q}</h2><small>{items.length} vastaavaa ilmoitusta</small></div><small>Päivitetty juuri nyt</small></div>
 {items.map((p,i)=><article className={'card '+(i===0?'chosen':'')} onClick={()=>setSelected(i)} key={i}>{i===0&&<label>🏆 PARAS DIILI</label>}<strong>{p[0]}</strong><small>{p[1]} · {p[4]}</small><div className="row"><b>{p[2]}</b><em>{p[6]}/100</em></div><div className="tags"><span>Kunto: {p[3]}</span><span>+ {p[5]} toimitus</span><span>{p[7]}</span></div></article>)}</section>
 <aside className="panel detail"><h2>{x[0]} · {x[2]}</h2><small>{x[1]} · {x[4]} · toimitus {x[5]}</small><div className="good">🟢 Hyvä ostos</div><div className="verdict"><b>Hinta on noin 14 % alle normaalin.</b><div className="bar"><i/></div><small>Arvioitu markkina-arvo: 175–195 €</small></div><div className="stats"><div><b>{x[6]}/100</b><small>Diili-pisteet</small></div><div><b>{x[2]}</b><small>Kokonaishinta</small></div><div><b>185 €</b><small>Arvioitu keskihinta</small></div><div><b>{x[5]}</b><small>Toimitus</small></div></div><b>Miksi tämä on hyvä?</b><ul><li>Hinta on alle vastaavien ilmoitusten keskitason.</li><li>Kunto vaikuttaa hyvältä.</li><li>Esimerkkidatassa kuitti ja pakkaus löytyvät.</li></ul><div className="watch"><input type="number" value={target} onChange={e=>setTarget(e.target.value)}/><button onClick={()=>setWatching(true)}>🔔 Vahdi hintaa</button></div>{watching&&<p className="notice">🔔 Hintavahti luotu: ilmoita alle {target} € löytyvistä vastaavista tuotteista.</p>}</aside></div></main></>;
}
createRoot(document.getElementById('root')).render(<App/>);
