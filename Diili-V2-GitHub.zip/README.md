# Diili 🚀

Käytettyjen tuotteiden ostoavustajan V2-prototyyppi.

## Ominaisuudet

- 🔎 tuotteen haku
- 🏆 Paras diili -pisteytys
- 💰 kokonaishinta toimituksineen
- 📊 arvioitu markkina-arvo
- 🟢 “Hyvä ostos” -arvio
- 🔔 hintavahti
- 📱 responsiivinen käyttöliittymä

> Huom: tämä versio käyttää vielä demo-dataa. Oikeat markkinapaikkalähteet lisätään seuraavassa vaiheessa.

## Käynnistä paikallisesti

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
npm run preview
```

## GitHubiin

Pura ZIP ja lataa **ZIPin sisältö** repositoryn juureen. Rakenteen pitää näyttää tältä:

```text
Diili/
├── index.html
├── package.json
├── vite.config.js
├── README.md
├── .gitignore
└── src/
    ├── main.jsx
    └── style.css
```
